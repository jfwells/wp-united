<?php

/** 
*
* WP-United -- phpBB version setting
*
* @package WP-United
* @version $Id: wp-united.php,v0.9.5[phpBB2]/v0.5.0[phpBB3] 2007/07/15 John Wells (Jhong) Exp $
* @copyright (c) 2006, 2007 wp-united.com
* @license http://opensource.org/licenses/gpl-license.php GNU Public License 
*
*/


if ( !defined('IN_PHPBB') ) {
	die("Hacking attempt");
	exit;
}

$phpbb_version = 'PHPBB3';

?>
