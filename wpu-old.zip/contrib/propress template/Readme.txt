ProPress is a template for WordPress 2.3 created by Chris Lynn, missoulamedia.com

The .zip file contains templates for WordPress 2.2 and 2.3 (with tag support). Simply copy the version you want to use to your wordpress wp-content/themes directory.

Chris requests that you leave the footer message intact.

To use this template, turning off WP-United template integration off is recommended.

What would be cool:
-------------------

If you spend time modifyng this template, please consider doing the following and submitting it for inclusion

-- set up the template such that it relies on phpBB's styles, not its own stylesheet.
-- remove the header and footer so the template can work better with template integration turned on.
