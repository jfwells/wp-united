<?php
if ( function_exists('register_sidebar') )
    register_sidebar();
?>
